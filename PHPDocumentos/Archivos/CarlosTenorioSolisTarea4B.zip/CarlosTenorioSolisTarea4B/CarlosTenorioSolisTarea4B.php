<?php
 if(!isset($add)){
    $add=-1;
 }
 $dbPath = $_SERVER['DOCUMENT_ROOT']."/";
      $dbFile = "Tarea4BD.sdb";
      $query = "$dbPath$dbFile";

     try { $db = new PDO("sqlite2:$query"); 
 
    } 

     catch(PDOException $e) { echo $e->getMessage()." Error: <span style='color:red;'>$query</span>"; }
  if (isset($_REQUEST['btnAction'])) {
      
      $boton=$_REQUEST['btnAction'];

      if($boton=="Agregar")
      {
        $sub=$_GET['qty']*$_GET['unit'];
        $totalFactura=0;
        $query="insert into 'producto' (descripcion,cantidad,valorUnitario,subTotal,numFactura)
                select '".$_GET['description']."','".$_GET['qty']."',".$_GET['unit'].",'".$sub."','".$_GET['number']."'";
          $result = $db->query("$query") or die("Error in query: <span style='color:red;'>$query</span>");

        $query = "SELECT * FROM producto where numFactura=".$_GET['number'];

        $result = $db->query($query) or die("Error in query: <span style='color:red;'>$query</span>"); 

            $row = $result->fetchall(PDO::FETCH_ASSOC);
            foreach($row as $array) {
                $totalFactura=$totalFactura+$array['subTotal'];

             }
        $taxes=$totalFactura*0.13;
        $totalFactura=$totalFactura+$taxes;

        $query = "UPDATE 'factura' SET impuestos=".$taxes.",totalMonto='".$totalFactura."' WHERE numFactura =".$_GET['number'];

        $result = $db->query("$query") or die("Error in query: <span style='color:red;'>$query</span>");

        header('Location: CarlosTenorioSolisTarea4B.php?id='.$_GET['number']);
      }
      elseif ($boton=='Eliminar') {
         $totalFactura=0;
          $query = "DELETE from 'producto' WHERE idProducto =".$_GET['idEliminar'];

          $result = $db->query("$query") or die("Error in query: <span style='color:red;'>$query</span>");

          $query = "SELECT * FROM producto where numFactura=".$_GET['id'];

          $result = $db->query($query) or die("Error in query: <span style='color:red;'>$query</span>"); 

            $row = $result->fetchall(PDO::FETCH_ASSOC);
            foreach($row as $array) {
                $totalFactura=$totalFactura+$array['subTotal'];

             }
               $taxes=$totalFactura*0.13;
               $totalFactura=$totalFactura+$taxes;
             $query = "UPDATE 'factura' SET impuestos=".$taxes.",totalMonto='".$totalFactura."' WHERE numFactura =".$_GET['id'];

        $result = $db->query("$query") or die("Error in query: <span style='color:red;'>$query</span>");

           header('Location: CarlosTenorioSolisTarea4B.php?id='.$_GET['id']);
      }
      elseif ($boton=='mas') {
        $add=1;
      }
      elseif ($boton="-") {
          $query = "DELETE from 'producto' WHERE numFactura =".$_GET['number'];

          $result = $db->query("$query") or die("Error in query: <span style='color:red;'>$query</span>");

          $query = "DELETE from 'factura' WHERE numFactura =".$_GET['number'];

          $result = $db->query("$query") or die("Error in query: <span style='color:red;'>$query</span>");

          header('Location: CarlosTenorioSolisTarea4B.php');
      }
  }
  elseif (isset($_GET['save'])) {
        if($_GET['save']==1)
        {
          $query="insert into 'factura' (numFactura,cliente,fecha,impuestos,totalMonto)
                select '".$_GET['number']."','".$_GET['client']."','".$_GET['date']."','0','0'";
         // echo $query;
          $result = $db->query("$query") or die("Error in query: <span style='color:red;'>$query</span>");
          header('Location: CarlosTenorioSolisTarea4B.php?id='.$_GET['number']);
        }
        elseif ($_GET['save']==2) {
            $query = "UPDATE 'factura' SET cliente='".$_GET['client']."',fecha='".$_GET['date']."' WHERE numFactura =".$_GET['number'];

            $result = $db->query("$query") or die("Error in query: <span style='color:red;'>$query</span>");    

            header('Location: CarlosTenorioSolisTarea4B.php?id='.$_GET['number']);
        }
  }
  elseif(isset($_GET['id'])) 
  {
    $guardar=2;
    $idGuarda=$_GET['id'];
    $dbPath = $_SERVER['DOCUMENT_ROOT']."/";
      $dbFile = "Tarea4BD.sdb";
      $query = "$dbPath$dbFile";

     try { $db = new PDO("sqlite2:$query"); 
        $query = "SELECT * FROM factura where numFactura =".$_GET['id'];

       $result = $db->query($query) or die("Error in query: <span style='color:red;'>$query</span>"); 

       $row = $result->fetchall(PDO::FETCH_ASSOC);

       foreach($row as $array) {
              $item[0]=$array['numFactura'];
              $item[1]=$array['fecha'];
              $item[2]=$array['cliente'];
              $item[3]=$array['impuestos'];
              $item[4]=$array['totalMonto'];
             }
    }
     catch(PDOException $e) { echo $e->getMessage()." Error: <span style='color:red;'>$query</span>"; }
  }
?>
<html>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <head>
        <title>Facturas</title>
    </head>
    <body>
     <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="GET">
      <div style="width: 200px; float: left; border-right:1px solid;">
        <h3>Facturas</h3>
        <table width="150" border=1>
          <?php
            $query = "SELECT * FROM factura";

            $result = $db->query($query) or die("Error in query: <span style='color:red;'>$query</span>"); 

            $row = $result->fetchall(PDO::FETCH_ASSOC);
            foreach($row as $array) {
              echo '<tr><td><a href="?id='.$array['numFactura'].
                     '" style="text-decoration:none;">'.
                     $array['numFactura'].'</a></td> 
                     <td>'.$array['cliente'].' </td></tr>';

             }

          ?>
        </table>
        <button name="btnAction" value="mas">+</button>
      </div>
      <div style="margin-left:250px;">
          <label>Numero: </label>
          <input name="number"  value="<?php if(isset($item[0])){echo $item[0];} ?>" <?php if(isset($_GET['id'])){ echo "readonly";} ?> <?php if(!empty($_GET)){echo "required";} ?>/>
          <label>Fecha: </label>
          <input name="date" value="<?php if(isset($item[1])){echo $item[1];} ?>"/> <br/>
          <br/>
          <label>Cliente: </label>
          <input name="client" value="<?php if(isset($item[2])){echo $item[2];} ?>" <?php if(!empty($_GET)){echo "required";} ?>/>

          <br/>
          <br/>
          <?php if(isset($_GET['id']))
          { ?>
          <table border=1>
            <thead>
                <tr>
                  <th>Qty</th>
                  <th>Descripcion</th>
                  <th>Valor Unitario</th>
                  <th>SubTotal</th>
                  <th>Comando</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    
                      $query = "SELECT * FROM producto where numFactura=".$_GET['id'];

                      $result = $db->query($query) or die("Error in query: <span style='color:red;'>$query</span>"); 

                      $row = $result->fetchall(PDO::FETCH_ASSOC);
                      foreach($row as $array) {
                          ?>
                          <tr>
                              <td><?php echo $array['cantidad'] ?></td>
                              <td><?php echo $array['descripcion'] ?></td>
                              <td><?php echo $array['valorUnitario'] ?></td>
                              <td><?php echo $array['subTotal'] ?></td>
                              <td><a href="<?php echo "CarlosTenorioSolisTarea4B.php?btnAction=Eliminar&idEliminar=".$array['idProducto']."&id=".$_GET['id']; ?>">Eliminar</a></td>
                          </tr>
                        <?php
                       }
                    
                  ?>
                  <tr>
                    <td><input size=1 name="qty" type="text" ></td>
                    <td><input name="description" type="text" ></td>
                    <td><input size=3 name="unit" type="text" ></td>
                    <td><input size=3 name="subTotal" type="text" readonly></td>
                    <td><input type="submit" name="btnAction" value="Agregar"></td>
                </tr>
            </tbody>  
          </table>
        <?php } ?>
          <br/>
          <br/>
          &nbsp;&nbsp;
          <input type="submit" name="btnAction" value="-">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <label>Impuestos: </label>
          <input size=3 name="taxes" value="<?php if(isset($item[3])){echo $item[3];} ?>" readonly/>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <label>Total: </label>
          <input size=3 name="Total" value="<?php if(isset($item[4])){echo $item[4];} ?>" readonly/>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <button name="save" value="<?php if(isset($_GET['id'])){ echo "2";} elseif(isset($_GET['btnAction'])) {echo "1";} else{echo -1;} ?>">Save</button>
        </div>
      </form>
    </body>
</html>